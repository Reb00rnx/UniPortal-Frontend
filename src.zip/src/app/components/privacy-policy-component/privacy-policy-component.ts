import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-privacy-policy-component',
  standalone: true,
  imports: [],
  templateUrl: './privacy-policy-component.html',
  styleUrl: './privacy-policy-component.css',
})
export class PrivacyPolicyComponent {

}
